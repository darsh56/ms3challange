package demo.darsh.ms3;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.logging.ConsoleHandler;
import java.util.logging.FileHandler;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.opencsv.CSVWriter;

public class Customer {
	private static final Logger LOGGER = Logger.getLogger(Customer.class.getName());

	public static void main(String[] args) throws ClassNotFoundException, SQLException {

		final int batchSize = 500;
		int count = 0;

		String csvFile = "E:\\ms3Interview.csv";
		String line = "";
		int count1 = 0;
		int count2 = 0;
		List<String[]> data = new ArrayList<String[]>();
		List<String[]> data2 = new ArrayList<String[]>();

		try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
			while ((line = br.readLine()) != null) {
				String[] country = line.split(",");

				if (country.length == 11) {

					if (!country[0].equals("") && !country[1].equals("") && !country[2].equals("")
							&& !country[3].equals("") && !country[4].equals("") && !country[5].equals("")
							&& !country[6].equals("") && !country[7].equals("") && !country[8].equals("")
							&& !country[9].equals("") && !country[10].equals("")) {

						String[] country2 = { country[0], country[1], country[2], country[3],
								country[4] + ',' + country[5], country[6], country[7], country[8], country[9],
								country[10] };
						data2.add(country2);
						count1++;

					} else {
						String[] country2 = { country[0], country[1], country[2], country[3],
								country[4] + ',' + country[5], country[6], country[7], country[8], country[9],
								country[10] };
						data.add(country2);
						count2++;
					}
				}

				else {

					data.add(country);
					count2++;
				}

			}

			// Inserting bad data to baddata csv file
			File file = new File("E:\\baddata.csv");
			FileWriter outputfile = new FileWriter(file, true);
			CSVWriter writer = new CSVWriter(outputfile);
			writer.writeAll(data);
			writer.close();
			outputfile.close();

			// Inserting good data inside database using batch 
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sonoo", "root", "root");
			con.setAutoCommit(false);
			Statement stmt = con.createStatement();
			String INSERT_RECORD = "insert into X(A, B, C, D, E, F, G, H, I, J) values(?,?,?,?,?,?,?,?,?,?)";
			PreparedStatement pstmt = con.prepareStatement(INSERT_RECORD);
			for (int counter = 0; counter < data2.size(); counter++) {
				String[] country3 = data2.get(counter);
				pstmt.setString(1, country3[0]);
				pstmt.setString(2, country3[1]);
				pstmt.setString(3, country3[2]);
				pstmt.setString(4, country3[3]);
				pstmt.setString(5, country3[4]);
				pstmt.setString(6, country3[5]);
				pstmt.setString(7, country3[6]);
				pstmt.setString(8, country3[7]);
				pstmt.setString(9, country3[8]);
				pstmt.setString(10, country3[9]);
				pstmt.addBatch();
				if (++count % batchSize == 0) {
					pstmt.executeBatch();
				}
				// execute the batch
			
			}
			int[] updateCounts = pstmt.executeBatch();
			con.commit();

			// Logging info management

			ConsoleHandler consoleHandler = new ConsoleHandler();
			FileHandler fileHandler = new FileHandler("E:\\ms3Interview.log");

			// Assigning handlers to LOGGER object
			LOGGER.addHandler(consoleHandler);
			LOGGER.addHandler(fileHandler);

			// Setting levels to handlers and LOGGER
			consoleHandler.setLevel(Level.ALL);
			// remove console log
			LOGGER.removeHandler(consoleHandler);

			fileHandler.setLevel(Level.ALL);
			LOGGER.setLevel(Level.ALL);

			LOGGER.config("Configuration done.");

			// System.out.println(count1);
			LOGGER.info("=====>> good data: " + count1);
			// to remove header count
			int bad=count2-2;
			LOGGER.info("=====>> bad data: " + bad);

			int count3 = count1 + bad;
			// System.out.println(count3);
			LOGGER.info("=====>> recieved data: " + count3);

			
			//to generate good data inside good.csv
			
		
		       
	        File file2 = new File("E:\\good.csv"); 
	        // create FileWriter object with file as parameter 
	        FileWriter outputfile2 = new FileWriter(file2,true); 
	  
	        // create CSVWriter object filewriter object as parameter 
	        CSVWriter writer2 = new CSVWriter(outputfile2); 
	        
	        // adding header to csv 
	        String[] header2 = { "A", "B", "C", "D", "E", "f", "g", "h", "i", "j" }; 
	        writer2.writeNext(header2); 
	        writer2.writeAll(data2); 
	        writer2.close();
	        outputfile2.close();
			
	
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
